package main

import (
	"fmt"
	"time"
)

func main()  {
	ch := time.After(time.Duration(2) * time.Second)
	select {
	case <-ch:
		fmt.Println("ok");
	}
}
